<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
<link href="css/searchcss.css" rel="stylesheet" type="text/css">
</head>

<body>
<div class="wraper">
<div class="header">
<div class="logo">
<img src="images/logo.png"/>
</div>
 <div id="hmenu"> 
<ul>
		<li><a href="#">MY HOME PAGE</a></li>
    	<li><a href="interestrecieved.php">INTEREST RECEIVED</a></li>
    	<!--<li><a href="int_snd.php">INTEREST SEND</a></li>-->
    	<li><a href="payment.php">PAYMENT PLANS</a></li>
    	<li><a href="userprofile.php">VIEW MY PROFILE</a></li>
        <li><a href="logout.php">LOGOUT</a></li>
	</ul>
</div> 
</div>
<div class="shosearch">
<?php
$servername="localhost";
$username="root";
$password="";

$conn=mysql_connect("$servername","$username","$password");
mysql_select_db('projectfrst');

if(isset($_POST['search']))
{
      $id=$_POST['id'];
     if($id!="")
	 {
		 $sql5="select * from frontregistration where frontregistration.id=$id";
		 $res5=mysql_query($sql5);
	  
        while($row=mysql_fetch_array($res5))
		{?>
	    <div class="mysearch1" align="center">
   		<h3>You searched for....</h3>
       <?php 

        echo "<img src='images/$row[pic]' height='200px' width='200px'><br>";
        echo "Name:".$row['fname']."<br>";
        echo "Date of birth:".$row['dob']."<br>";
        echo "Denomination:".$row['denom']."<br>";
									 
		$rid=$row['id']; 
		echo "<a href='viewotherprofile.php?id=$rid'>view profile</a>";	
		?>
        </div>
        <?php
		}
	 }
}
	 ?>
</div>
	</div>
    </div>	
</body>
</html>
