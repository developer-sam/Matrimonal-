<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Profile</title>

<link href="css/success_storycss.css" rel="stylesheet" type="text/css">
<body>

<div class="wraper">
<div class="header">
<div class="logo">
<img src="images/logo.png"/>
</div>
 <div id="hmenu"> 
<ul>
		<li><a href="#">MY HOME PAGE</a></li>
    	<li><a href="interestrecieved.php">INTEREST RECEIVED</a></li>
    	<!--<li><a href="int_snd.php">INTEREST SEND</a></li>-->
    	<li><a href="payment.php">PAYMENT PLANS</a></li>
    	<li><a href="userprofile.php">VIEW MY PROFILE</a></li>
        <li><a href="logout.php">LOGOUT</a></li>
	</ul>
</div> 
</div>

<div class="container">
<div class="successub">
<center>

<form action="#" method="post" name="forms1" enctype="multipart/form-data"  >
<h2 style="font-style:oblique; color:#ff0000;"><center>YOUR PROFILE DETAILS !!!</h1></center>
<center><table bordercolor="red" >
<tr>
<th>Groom's Details *</th><td><input type="text" name="gname" id="gn" placeholder="Enter Name"></td><td><input type="text" name="gid" id="gid" placeholder="Enter UserID"></td>
</tr>
<tr>
<th>Bride's Details *</th><td><input type="text" name="bname" id="bn" placeholder="Enter Name"></td><td><input type="text" name="bid" id="bid" placeholder="Enter UserID"></td>
</tr>

<tr>
<th>Wedding Date * Date of Birth</th> <td> <input type="date" name="dob"><br></td></tr></td>
</tr>
<tr>
<th>Email ID *</th><td><input type="text" name="email" id="eml" placeholder="Enter your valid Email ID"> </td>
</tr>
<tr>
<th>Mobile Number *</th><td><input type="text" name="number" id="num"  placeholder="Enter Phone number"></td>
</tr>
<tr>
<th>Contact Address *</th><td><textarea name="contact_address" rows="4" cols="30"></textarea></td></tr>
<tr>
<th>Your comments on Life Partner Matrimony *</th><td><textarea name="comments" rows="4" cols="30"></textarea></td></tr>
 <tr><th>Send us your wedding / engagement photos *</th><td><input type="file" name="photos[]" multiple/></td>   
 </tr>
 <tr>
<td><input type="checkbox" name="agree" id="agree" col span="1">I have agree to publish my wedding photos as cover page or home page in Life Partner Matrimony website
</tr>
 <tr><td><td> <input type="submit" value="SUBMIT" name="submit"></td></td></tr>
 </div>
</div>
</form>
</body>
</html>
<?php

$con=mysql_connect("localhost","root","");
mysql_select_db("projectfrst");
session_start();

if(isset($_POST['submit']))
{
	$gname=$_POST['gname'];
	$gid=$_POST['gid'];
	$bname=$_POST['bname'];
	$bid=$_POST['bid'];
	$wedding= $_POST['dob'];
	$email=$_POST['email'];
	$number=$_POST['number'];
	$contact_address=$_POST['contact_address'];
	$comments=$_POST['comments'];
	$path="images/";
	$c=count($_FILES["photos"]["name"]);
	$p="";
	for($i=0;$i<$c;$i++)
	{
		$target=$path.basename($_FILES["photos"]["name"][$i]);
		$p.=basename($_FILES["photos"]["name"][$i]).",";
		
	    move_uploaded_file($_FILES['photos']['tmp_name'][$i],$target);
		
	}
	
	echo $sql="insert into success(gname,gid,bname,bid,wedding,email,number,contact_address,comments,image)values('$gname','$gid','$bname','$bid','$wedding','$email','$number','$contact_address','$comments','$p')";
	mysql_query($sql);

	header("location:more_couples.php");
}

