<!doctype html>
<html>
<head>
<link href="stylepay.css" rel="stylesheet" type="text/css" />
<meta charset="utf-8">
<title>Untitled Document</title>
<script src="js/jquery-1.11.3.min.js"></script>
<script>
$(document).ready(function(){
    $("#round").click(function(){
       $("#div0").show();
	    $("#div1").fadeIn(2000);
		$("#div2").fadeIn(4000);
		$("#div3").fadeIn(6000);

        //$("#div2").fadeIn("slow");
        //$("#div3").fadeIn(3000);
    });
	$(".bigbutton").click(function(){
		
		$("#div5").fadeIn(4000);
		
		 });
		 
		 
		 $("#div1").click(function(){
		$(".title1").fadeIn(4000);
		document.getElementById("amt").value=600;
		 });
		 
		 $("#div2").click(function(){
		$(".title2").fadeIn(4000);
		document.getElementById("amt").value=1200;
		 });
		 
		 $("#div3").click(function(){
		$(".title3").fadeIn(4000);
		document.getElementById("amt").value=1500;
		 });
		 
});
</script>
</head>

<body>
<div class="login" style="height:250px;width:1600px;">
</div>
<div class="head" style="width:753px;height:313px;">
<p class="content1" >
<strong>Are You seriously looking for a life partner?<br>
Free Membership has limited benefits while paid membership will give you more <font color="RED" size="2">CHOICES,</font>Additional<font color="RED" size="2">BENEFITS</font>and
Faster <font color="RED" size="2">RESULTS</font></strong>.<br><br>

<a href="#div3" onclick="document.body.scrollTo(0, document.getElementById('div3').offsetTop); return false;">
<input id="round" type="button" value="Upgrade!"  />
</a><p class="content2"><strong>Your Free Membership is for remaining 30days only!</strong></p>
</div>

<div class="next" style="height:500px;width:753px;display:none;" id="div0" >
<a href="#div5" onclick="document.body.scrollTo(0, document.getElementById('div5').offsetTop); return false;">

<input class="bigbutton" id="div1" type="submit" name="s1" value="Silver Badge" style="display:none;" /><font size="+2" color="#FCF9F9">₹600</font>
<br>
<input class="bigbutton" id="div2"  type="submit" name="s2" value="Golden Badge" style="display:none;"  /><font size="+2" color="#FCF9F9">₹1200</font>
<br>
<input class="bigbutton" id="div3" type="submit" name="s3" value="Platinum Badge" style="display:none;"  /><font size="+2" color="#FCF9F9">₹1500</font></a>
<p class="pay" ><em><strong>Silver Badge:Valid For  three months and you will be again upgrade or renue the policy after three months
<br>
Golden  Badge:Valid For  six months and you will be again upgrade or renue the policy after six months
<br>
Platinum Badge:Valid For one year and you will be again upgrade or renue the policy after one year.This is our most reduction plan for the customers.we recommend platinum badge for our dear customers
<br>
Terms and Conditions Applied
</p> 
</form>
</div>
<form action="#" method="post" enctype="multipart/form-data">
<?php

 $con=mysql_connect("localhost","root","");
mysql_select_db("projectfrst");
session_start();
$newid=$_SESSION["regrsid"];

 $sql="select * from frontregistration where id=$newid";
$res=mysql_query($sql);

while($row=mysql_fetch_array($res))
{ 

	 echo $exp=$row['exdate'];
	
	  if(isset($_POST['subb']))
      {
	   $amt=$_POST['txt1'];
	  
	  if($amt==600)
	   {
		   
		    $exp = date('Y-m-d', strtotime("+3 months", strtotime($exp)));
			
		     $sql="update frontregistration set exdate='$exp' where frontregistration.id=$newid";
		   mysql_query($sql);
	   }
	   
	    else if($amt==1200)
	   {
		    
				$exp = date('Y-m-d', strtotime("+6 months", strtotime($exp)));
		    	 $sql="update frontregistration set exdate='$exp' where frontregistration.id=$newid";
		  		 mysql_query($sql);
	   }
	   
	    if($amt==1500)
	   {
		   $exp = date('Y-m-d', strtotime("+9 months", strtotime($exp)));
		     $sql="update frontregistration set exdate='$exp' where frontregistration.id=$newid";
		      mysql_query($sql);
	   }
	   
   header("location:userprofile.php");
   }
}

?>
</form>



<div class="money" id="div5" style="height: 500px; width: 753px;display:none" color: #FFFFFF;">
<div class="title1" style="display:inline";>
<p>SILVER 600 INR</p>
</div>
<div class="title2" style="display:inline";>
<p>GOLD 1200 INR</p>
</div>
<div class="title3" style="display:inline";>
<p>PLATINUM 1500</p>
</div>

<form name="paypal" action="" method="post">
  <table width="683" height="362">
    <tr>
<th><h4><em>Amount</em></h4></th>
<td><br>
  <input type="text" name="txt1"  id="amt">
  <br>
<span>We Are Providing doorstep collection for free.Kindly Give The Address</span></td>
</tr> 
<tr>
<th>Adress</th>
<td><textarea name="addr"></textarea></td>
</tr>
<tr>
<th>Mobile Number</th>
<td><input type="text" name="txt2"></td>
</tr>
<tr>
<td>               <input type="submit" name="subb" value="OK"></td>
</tr>
</table>
</form>
</div>

</table>
</form>
</div>