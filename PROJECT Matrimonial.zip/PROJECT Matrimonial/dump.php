<!doctype html>
<html><head>
<meta charset="utf-8">
<title>Logo</title>

 <link href="css/homepagecss.css" rel="stylesheet" type="text/css">
        
        <link rel="stylesheet" href="css/validationEngine.jquery.css" type="text/css"/>
        <script src="js/jquery-1.6.min.js" type="text/javascript"></script>
        <script src="js/jquery.validationEngine.js" type="text/javascript" ></script>
		<script src="js/languages/jquery.validationEngine-en.js" type="text/javascript" charset="utf-8"></script>
        <script>
            
			jQuery(document).ready(function(){
			// binds form submission and fields to the validation engine
			jQuery("#myform").validationEngine();
			jQuery('#myform').validationEngine('validate');
		});
       </script>
       <script>
            
			jQuery(document).ready(function(){
			// binds form submission and fields to the validation engine
			jQuery("#newform").validationEngine();
			jQuery('#newform').validationEngine('validate');
		});
       </script>
</head>

<body>


<div class="wraper">
<div class="header">

<div class="headlog">

<form method="post" action="login_post.php" enctype="multipart/form-data" id="myform">
<label><font face="Gill Sans" color="white">Username</font>
<input type="text"  name="user" id="tt" 
class="validate[required]" ></label>
        <font face="Gill Sans" color="white">Password</font>
         <input type="password" name="pass" id="ts"
         class="validate[required]" ><br>

        <input type="submit" name="login" value="Login"/>
        
        </form>
 </div>

</div>
<div class="container">

<div class="slider">

<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
</head>
<body style="padding:0px; margin:0px; background-color:#fff;font-family:Arial, sans-serif">

    <!-- #region Jssor Slider Begin -->

    <!-- Generator: Jssor Slider Maker -->
    <!-- Source: http://www.jssor.com/demos/simple-fade-slideshow.slider -->
    
    <!-- This demo works without jquery library. -->

    <script type="text/javascript" src="js/jssor.slider.min.js"></script>
    <!-- use jssor.slider.debug.js instead for debug -->
    <script>
        jssor_1_slider_init = function() {
            
            var jssor_1_SlideshowTransitions = [
              {$Duration:1200,$Opacity:2}
            ];
            
            var jssor_1_options = {
              $AutoPlay: true,
              $SlideshowOptions: {
                $Class: $JssorSlideshowRunner$,
                $Transitions: jssor_1_SlideshowTransitions,
                $TransitionsOrder: 1
              },
              $ArrowNavigatorOptions: {
                $Class: $JssorArrowNavigator$
              },
              $BulletNavigatorOptions: {
                $Class: $JssorBulletNavigator$
              }
            };
            
            var jssor_1_slider = new $JssorSlider$("jssor_1", jssor_1_options);
            
            //responsive code begin
            //you can remove responsive code if you don't want the slider scales while window resizing
            function ScaleSlider() {
                var refSize = jssor_1_slider.$Elmt.parentNode.clientWidth;
                if (refSize) {
                    refSize = Math.min(refSize, 600);
                    jssor_1_slider.$ScaleWidth(refSize);
                }
                else {
                    window.setTimeout(ScaleSlider, 30);
                }
            }
            ScaleSlider();
            $Jssor$.$AddEvent(window, "load", ScaleSlider);
            $Jssor$.$AddEvent(window, "resize", ScaleSlider);
            $Jssor$.$AddEvent(window, "orientationchange", ScaleSlider);
            //responsive code end
        };
    </script>

    <style>
        
        /* jssor slider bullet navigator skin 05 css */
        /*
        .jssorb05 div           (normal)
        .jssorb05 div:hover     (normal mouseover)
        .jssorb05 .av           (active)
        .jssorb05 .av:hover     (active mouseover)
        .jssorb05 .dn           (mousedown)
        */
        .jssorb05 {
            position: absolute;
        }
        .jssorb05 div, .jssorb05 div:hover, .jssorb05 .av {
            position: absolute;
            /* size of bullet elment */
            width: 16px;
            height: 16px;
            background: url('img/b05.png') no-repeat;
            overflow: hidden;
            cursor: pointer;
        }
        .jssorb05 div { background-position: -7px -7px; }
        .jssorb05 div:hover, .jssorb05 .av:hover { background-position: -37px -7px; }
        .jssorb05 .av { background-position: -67px -7px; }
        .jssorb05 .dn, .jssorb05 .dn:hover { background-position: -97px -7px; }

        /* jssor slider arrow navigator skin 12 css */
        /*
        .jssora12l                  (normal)
        .jssora12r                  (normal)
        .jssora12l:hover            (normal mouseover)
        .jssora12r:hover            (normal mouseover)
        .jssora12l.jssora12ldn      (mousedown)
        .jssora12r.jssora12rdn      (mousedown)
        */
        .jssora12l, .jssora12r {
            display: block;
            position: absolute;
            /* size of arrow element */
            width: 30px;
            height: 46px;
            cursor: pointer;
            background: url('img/a12.png') no-repeat;
            overflow: hidden;
        }
        .jssora12l { background-position: -16px -37px; }
        .jssora12r { background-position: -75px -37px; }
        .jssora12l:hover { background-position: -136px -37px; }
        .jssora12r:hover { background-position: -195px -37px; }
        .jssora12l.jssora12ldn { background-position: -256px -37px; }
        .jssora12r.jssora12rdn { background-position: -315px -37px; }
    </style>


    <div id="jssor_1" style="position: relative; margin: 0 auto; top: 0px; left: 0px; width: 600px; height: 300px; overflow: hidden; visibility: hidden;">
        <!-- Loading Screen -->
        <div data-u="loading" style="position: absolute; top: 0px; left: 0px;">
            <div style="filter: alpha(opacity=70); opacity: 0.7; position: absolute; display: block; top: 0px; left: 0px; width: 100%; height: 100%;"></div>
            <div style="position:absolute;display:block;background:url('img/loading.gif') no-repeat center center;top:0px;left:0px;width:100%;height:100%;"></div>
        </div>
        <div data-u="slides" style="cursor: default; position: relative; top: 0px; left: 0px; width: 600px; height: 300px; overflow: hidden;">
            <div data-p="112.50" style="display: none;">
                <img data-u="image" src="img/02.jpg" />
            </div>
            <div data-p="112.50" style="display: none;">
                <img data-u="image" src="img/04.jpg" />
            </div>
            <div data-p="112.50" style="display: none;">
                <img data-u="image" src="img/05.jpg" />
            </div>
            <div data-p="112.50" style="display: none;">
                <img data-u="image" src="img/09.jpg" />
            </div>
            <a data-u="add" href="http://www.jssor.com" style="display:none">Jssor Slider</a>
        
        </div>
        <!-- Bullet Navigator -->
        <div data-u="navigator" class="jssorb05" style="bottom:16px;right:16px;" data-autocenter="1">
            <!-- bullet navigator item prototype -->
            <div data-u="prototype" style="width:16px;height:16px;"></div>
        </div>
        <!-- Arrow Navigator -->
        <span data-u="arrowleft" class="jssora12l" style="top:0px;left:0px;width:30px;height:46px;" data-autocenter="2"></span>
        <span data-u="arrowright" class="jssora12r" style="top:0px;right:0px;width:30px;height:46px;" data-autocenter="2"></span>
    </div>
    <script>
        jssor_1_slider_init();
    </script>

    <!-- #endregion Jssor Slider End -->
</body>
</html>

</div>


</div>
</div>

<div class="sidebar">

<div class="form">
<table >


<form method="post" action="">
  <tr> <th>Select Year: </th><td> <select name="year">
        						<option hidden="">--year--</option>
                    <?php for($i=2000;$i<=2015;$i++) {?>
        			<option value="<?php echo $i ?>"><?php echo $i ?></option>
                    <?php }?>
                    </select></td></tr>
    <tr> <th>Select Company: </th><td> <select name="company">
        						<option hidden="">--company--</option>
                    <option value="bmw">BMW</option>
                    <option value="audi">AUDI</option>
                    <option value="jaggur">JAGGUAR</option>
                    <option value="hummer" >HUMMER</option>
                    </option></select><br></td></tr>
     <tr> <th>Select Model: </th><td> <select name="model">
        						<option hidden="">--model--</option>
                    <option value="xuv">XUV</option>
                    <option value="cooper">COOPER</option>
                    <option value="convertable">CONVERTABLE</option>
                    </option></select><br></td></tr>
      <tr> <th>Select Version: </th><td> <select name="version">
        						<option hidden="">--version--</option>
                    <option value="1s">Base Series</option>
                    <option value="2s">Second Series</option>
                    <option value="3s">third Series</option>
                    <option value="4s">fourth Series</option>
                    <option value="5s">fifth Series</option>
                    <option value="6s">sixth Series</option>
                    </option></select><br></td></tr>
              
 </table>

 <center><input type="submit" name="submit" value="go"></center></div>


</div>

</div>










</body>
</html>
