<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Profile</title>

<link href="css/userprofilecss.css" rel="stylesheet" type="text/css">
<body>

<div class="wraper">
<div class="header">
<div class="logo">
<img src="images/logo.png"/>
</div>
 <div id="hmenu"> 
<ul>
		<li><a href="#">MY HOME PAGE</a></li>
    	<li><a href="interestrecieved.php">INTEREST RECEIVED</a></li>
    	<!--<li><a href="int_snd.php">I NTEREST SEND</a></li>-->
    	<li><a href="payment.php">PAYMENT PLANS</a></li>
    	<li><a href="userprofile.php">VIEW MY PROFILE</a></li>
        <li><a href="logout.php">LOGOUT</a></li>
	</ul>
</div> 
</div>
<div class="container">
<?php
session_start();

$con=mysql_connect("localhost","root","");
mysql_select_db("projectfrst");
$newid=$_SESSION["regrsid"];
 $sql="select * from frontregistration where id=$newid";
 $res=mysql_query($sql);
 $fet=mysql_fetch_object($res);
$id=$fet->id;
echo "<h1 style='text-align:center' >Welcome "  .$fet->fname. "</h1>";

?>
<div class="samlpro">
<table bordercolor="#F0090D">
<tr><th><font face="Gill Sans" color="#F00538">Profile Pic</th><td><img src="images/<?php echo $fet->pic;?>" height="100" width="100"></td></tr>
<tr><th><font face="Gill Sans" color="#F00538">Ur Matrimony Id </th><td><?php echo $row=$fet->id;?> </td></tr
><tr><th><font face="Gill Sans" color="#F00538">Name</th><td><?php echo $row=$fet->fname;?> </td></tr>
<tr><th><font face="Gill Sans" color="#F00538">Account Created Date</th><td><?php echo $cdate=$fet->cdate;?></td></tr>
<tr><th><font face="Gill Sans" color="#F00538">Account Expiry Date</th><td><?php echo $exdate=$fet->exdate;?></td></tr>
<tr><th><font face="Gill Sans" color="#F00538">View your Profile</th><td><?php echo "<a href='viewmyprofile.php?id=$id'>Click Here</a>";?></td></tr>
</table>

<div class="search">
<form action="membersearch.php" method="post" name="form1" enctype="multipart/form-data" >
<center>SEARCH A PARTNER</center>
<table bordercolor="#F0090D">
<tr>
<th ><font face="Gill Sans" color="#F00538">Looking For</th><td><td><input type="radio" name="gender" value="female">Bride<input type="radio" name="gender" value="male"> Groom</td></td>
</tr>
<tr>
<th ><font face="Gill Sans" color="#F00538">Age </th> <td >From</td><td><select name="afrom" id="afrom">
<option value="">--select--</option>
<?php for ($x =18; $x <= 45; $x++){?>
<option value="<?php  echo $x; ?>" > <?php  echo $x; ?>   
<?php }?>
</option></td></tr>             
<tr>
<td><td >To</td></td><td><select name="ato" id="ato" >
<option value="">--select--</option>
<?php for ($x =18; $x <= 45; $x++){?>
<option value="<?php  echo $x; ?>" > <?php  echo $x; ?>  
<?php }?>             
</option></td></tr>
<tr>
<th><font face="Gill Sans" color="#F00538">Height</th><td >From</td><td><select name="hfrom" id="hfrom">
<option value="">centimetres</option>
<?php for($x = 130; $x <= 250; $x++) {?>
<option value="<?php echo $x;?>"  > <?php echo $x;?>
<?php } ?>
</option>
</td>
</tr>
<td><td>To</td></td><td><select name="hto" id="hto"/>
<option value="">centimetres</option>
<?php for($x = 130; $x <= 250; $x++) {?>
<option value="<?php echo $x;?>"  > <?php echo $x;?>
<?php } ?>
</option>
</td>
</tr>
<th><font face="Gill Sans" color="#F00538">Community</th><td><td><select name="comm" id="comm" />
<option value="">--select--</option>
<option value='catholic'>Catholic</option>
<option value='noncatholic'>NonCatholic</option>
</td></td></tr>
<tr>
<th><font face="Gill Sans" color="#F00538">Work Place</th><td><td>
						<?php

								$sql="select * from country";
								$res=mysql_query($sql);
										?>
						<select name="wplace">
						<option value="">Select your country</option>
									<?php
									while($fetch=mysql_fetch_object($res))
									{
									?>
                                     <option value="<?php echo $fetch->id;?>"><?php echo $fetch->country_name;?></option>
 									<?php   
									}
									?></select><br></td></tr></select><br></td></tr>

<tr><tr>
<th><font face="Gill Sans" color="#F00538">Member search</th><td><td><input type="submit" name="memsearch" value="SEARCH"></td></td>
</tr></tr>

</form>
</table>
<table bordercolor="#F0090D">
<form method="post" action="idsearch.php" enctype="multipart/form-data">
<tr>
<th><font face="Gill Sans" color="#F00538">Search by Matrimony ID</th><td><td><input type="text" name="id" ></td></td>
<td><td><input type="submit" name="search" value="GO"></td></td>
</div></form>
</table>
</div>

<div class="match">
<form action="#" method="post" name="form4" enctype="multipart/form-data"  >
<td><center>My Matches</center><br><a href="more_matchs.php"> More matches</a></td>
 <?php

$con=mysql_connect("localhost","root","");
mysql_select_db("projectfrst");
$newid=$_SESSION["regrsid"];
 $sql="select gender from frontregistration where id=$newid";
	$result=mysql_query($sql);	
	$row=mysql_fetch_object($result);
	 $gender=$row->gender;	
				 if($gender=='male')
				 {
				 
			    $sql6="select * from frontregistration where gender='female' limit 2";
				$res6=mysql_query($sql6);
            
                    while($row=mysql_fetch_array($res6))
                   {
                                   
                                    echo "<tr><td><img src='images/$row[pic]' height='200px' width='250px' ><br>";
                                   ?>
									<div class="mymatch1" align="center">
                                    <?php
								    echo "Name:".$row['fname']."<br>";
                                    echo "Date of birth:".$row['dob']."<br>";
                                    echo "Denomination:".$row['denom']."<br>";
									$rid=$row['id']; 
									echo "<a href='viewotherprofile.php?id=$rid'>View profile</a>";	
									?></tr>
									 </div>
									

					<?php			 
	               }
				 }
                      
				 else
				 { 
				   $sql9="select * from frontregistration  where gender='male' limit 2";
				   $res9=mysql_query($sql9);
            
                   while($row=mysql_fetch_array($res9))
                    {         
								 echo "<tr><img src='images/$row[pic]' height='200px' width='250px'><br>";
                                    ?>
									<div class="mymatch2" align="center">
                                    <?php
                                   
                                    echo "Name:".$row['fname']."<br>";
                                    echo "Date of birth:".$row['dob']."<br>";
                                    echo "Denomination:".$row['denom']."<br></tr>";
									$rid=$row['id']; 
									echo "<a href='viewotherprofile.php?id=$rid'>View profile</a>";	
									
                                   ?>
									 </div>
								 <?php

									
					}
								
				 }
                       
                
				 ?>
</form></table>
</div>

<div class="activity">
<center><font face="Lucida Console, Lucida Sans Typewriter, Monaco, Courier New, monospace" color="#000000">Activity Summary</font></center>
<table bordercolor="#F0090D">
<form action="#" method="post" name="" enctype="multipart/form-data" >

<tr><th>Interest Messages</th></tr><br>
<font face="Gill Sans" color="#F00538">
<?php
        
		
     	echo "<tr><th>Interest received : </th>";
	    $sql1="select count(status) from interest where receiver_id=$newid";
		 $res1=mysql_query($sql1);
		 $row1=mysql_fetch_array($res1);
		 $Interest_received=$row1["count(status)"];
		 echo "<td>$Interest_received</td></tr>";
		
		
		echo "<tr><th>Awaiting my reply : </th>";
         $sql2="select count(status) from interest where receiver_id=$newid and status=1 ";
		 $res2=mysql_query($sql2);
		 $row2=mysql_fetch_array($res2);
		 $Awaiting_my_reply=$row2["count(status)"];
		 echo "<td>$Awaiting_my_reply</td></tr>";
		 
		 
        echo "<tr><th>Interest send : </th>";
	    $sql3="select count(status) from interest where sender_id=$newid";
		 $res3=mysql_query($sql3);
		 $row3=mysql_fetch_array($res3);
		 $Interest_send=$row3["count(status)"];
		 echo "<td>$Interest_send</td></tr>";
         
		

		echo "<tr><th>Reply pending : </th>";
	     $sql4="select count(status) from interest where sender_id = $newid and status=1";
	   	 $res4=mysql_query($sql4);
		 $row4=mysql_fetch_array($res4);
		 $Reply_pending=$row4["count(status)"];
		 echo "<td>$Reply_pending</td></tr>";
		
	
     ?>
     
     <tr><th>Acceptance</th></tr>
     <?php
	
 		echo "<tr><th>Accepted by me :  </th>";
	    $sql5="select count(status) from interest where receiver_id = $newid and status=2";
	    $res5=mysql_query($sql5);
		 $row5=mysql_fetch_array($res5);
		 $Accepted_by_me=$row5["count(status)"];
		 echo  "<td>$Accepted_by_me</td></tr>";
		
		
		echo "<tr><th>Accepted me : </th>";
	    $sql6="select count(status) from interest where sender_id = $newid and status=2";
		 $res6=mysql_query($sql6);
		 $row6=mysql_fetch_array($res6);
		 $Accepted_me=$row6["count(status)"];
		 echo "<td>$Accepted_me</td></tr>";
		 
	 
 
 ?>
</table>
</div>
 
</div>
