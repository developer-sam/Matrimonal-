<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
<?php
$servername="localhost";
$username="root";
$password="";

$conn=mysql_connect("$servername","$username","$password");
mysql_select_db('projectfrst');
session_start();



if(isset($_POST["submit"]))
{
		echo $fname=$_POST["fname"];
		$age=$_POST["age"];
		$gender=$_POST["gender"];
		$dob=$_POST["dob"];
		$community=$_POST["community"];
		$denom=$_POST["denom"];
		$centi=$_POST["centi"];
		$feet=$_POST["feet"];
		$native=$_POST["native"];
		$mobile=$_POST["mobile"];
		$email=$_POST["email"];
		$user=$_POST["user"];
		$pass=$_POST["pass"];
		$cdate=$_POST["cdate"];
		$exdate=$_POST["exdate"];
		
		 $sql="insert into frontregistration (fname,age,gender,dob,community,denom,centi,feet,native,mobile,email,cdate,exdate) values ('$fname','$age','$gender','$dob','$community','$denom','$centi','$feet','$native','$mobile','$email','$cdate','$exdate')";
		$res=mysql_query($sql);
		echo $id=mysql_insert_id();
		
		
		$sql1="insert into log(regid,user,Pass) values ('$id','$user','$pass')";
		$res1=mysql_query($sql1);
		
		echo $_SESSION['ids']=$id;
		echo $_SESSION['fname']=$fname;
	
		header("Location:update_reg.php");
}


?>


</body>
</html>
