<!doctype html>
<html>
<head>
<meta charset="utf-8">

<title>Untitled Document</title>
<link href="css/morecouplescss.css" rel="stylesheet" type="text/css">
</head>
<body>

<div class="wraper">
<div class="header">
<div class="logo">
<img src="images/logo.png"/>
</div>
 <div id="hmenu"> 
<ul>
		<li><a href="#">MY HOME PAGE</a></li>
    	<li><a href="interestrecieved.php">INTEREST RECEIVED</a></li>
    	<!--<li><a href="int_snd.php">INTEREST SEND</a></li>-->
    	<li><a href="payment.php">PAYMENT PLANS</a></li>
    	<li><a href="userprofile.php">VIEW MY PROFILE</a></li>
        <li><a href="logout.php">LOGOUT</a></li>
	</ul>
</div> 
</div>



</div>
<div class="successname">

<br>
 
<?php
$con=mysql_connect("localhost","root","");
mysql_select_db("projectfrst");

 $sql="select * from success ";
 $res=mysql_query($sql);
 while($row=mysql_fetch_array($res))
 {
	 $gn=$row['gname'];
     $bn=$row['bname'];
	$pict=$row['image'];
	 $pic=explode(",",$pict);
	$c=count($pic);
		for($i=0;$i<1;$i++)
									{
								       echo  "<tr><td><center><img src='images/$pic[$i]' height='200px' width='200px'></td>";
									    echo "<td><a href='view_couple_details.php?id=1' font-color:'white' ></td></tr>".$gn." "."&"." ".$bn."</a>";
									}		
	//  echo "<td><a href='view_couple_details.php?id=1' font-color:'white' >".$gn." "."&"." ".$bn."</a></td>";
	  
 }
 ?>

</div>
</table>
</div>
</div>

</body>
</html>