<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Logo</title>

<link href="css/invalidlogincss.css" rel="stylesheet" type="text/css">

<body>
<div class="wraper">
<div class="header">
<div class="logo">
<img src="images/logo.png"/>
</div>

</div>
<div class="container">
<h2>Sorry Invalid Username And Password !!!!!!</h2>
<h3>It might be spelling mistake..<a href="registration.php">Login Please</a></h3>
<h3>If you are a new candidate kindly Register <a href="registration.php">Sign Up</h23>
 </div>
</div>










</body>
</html>
