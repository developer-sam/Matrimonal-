<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>More matches</title>

<link href="css/morematchcss.css" rel="stylesheet" type="text/css">
</head>

<div class="wraper">
<div class="header">
<div class="logo">
<img src="images/logo.png"/>
</div>
<div id="hmenu"> 
<ul>
		<li><a href="#">MY HOME PAGE</a></li>
    	<li><a href="interestrecieved.php">INTEREST RECEIVED</a></li>
    	<!--<li><a href="int_snd.php">INTEREST SEND</a></li>-->
    	<li><a href="payment.php">PAYMENT PLANS</a></li>
    	<li><a href="userprofile.php">VIEW MY PROFILE</a></li>
        <li><a href="logout.php">LOGOUT</a></li>
	</ul>
</div> 

</div>
<div class="container">
<div class="match">
<body>

<?php      
$con=mysql_connect("localhost","root","");
mysql_select_db("projectfrst");

session_start();
$newid=$_SESSION["regrsid"];
 $sql="select gender from frontregistration where id=$newid";
	$result=mysql_query($sql);	
	$row=mysql_fetch_object($result);
	 $gender=$row->gender;	
			if($gender=='male')
			{
				 
				 $sql="select * from frontregistration where gender='female'";
			     $res=mysql_query($sql);
            
                 while($row=mysql_fetch_array($res))
                 {
                                    echo "<img src='images/$row[pic]' height='200px' width='200px'><br>";
									  $rid=$row['id'];  
									echo "<a href='viewotherprofile.php?id=$rid'>view profile</a><br>";  			
								 
                                    echo "Name:".$row['fname']."<br>";
                                    echo "Date of birth:".$row['dob']."<br>";
                                    echo "Denomination:".$row['denom']."<br>";
									
				 }
		 }
                      
		 else
		 { 
				 $sql1="select * from frontregistration where gender='male'";
				 $res=mysql_query($sql1);
           
                  while($row=mysql_fetch_array($res))
				
                                  
                  {
                                   
								    echo "<img src='images/$row[pic]' height='200px' width='200px'><br>";
								    $rid=$row['id'];
									 echo "<a href='viewotherprofile.php?id=$rid'>view profile</a><br>";
                                  
                                   echo "Name:".$row['fname']."<br>";
                                   echo "Date of birth:".$row['dob']."<br>";
                                   echo "Denomination:".$row['denom']."<br>";
								   
                                   
								
								  
				  }
								
	       }
                         
               
 ?></div>
                 
       </div>
       </div>          

 
 
</body>
</html>