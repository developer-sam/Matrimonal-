<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Profile</title>


<link href="css/interestcss.css" rel="stylesheet" type="text/css">
<body>

<div class="wraper">
<div class="header">
<div class="logo">
<img src="images/logo.png"/>
</div>
<div id="hmenu"> 
<ul>
		<li><a href="#">MY HOME PAGE</a></li>
    	<li><a href="interestrecieved.php">INTEREST RECEIVED</a></li>
    	<!--<li><a href="int_snd.php">INTEREST SEND</a></li>-->
    	<li><a href="payment.php">PAYMENT PLANS</a></li>
    	<li><a href="userprofile.php">VIEW MY PROFILE</a></li>
        <li><a href="logout.php">LOGOUT</a></li>
	</ul>
</div> 

</div>
<div class="container">
<div class="interest">
<form action="" method="post" enctype="multipart/form-data">
        <center> <table bordercolor="#F0090D">
         <tr><th>Request send by</th><th>Native place</th><th>Date of birth</th><th>Education</th><th>Occupation</th><th>View full profile</th><th>Action</th></tr><tr>

<?php
session_start();
$servername="localhost";
$username="root";
$password="";

$conn=mysql_connect("$servername","$username","$password");
mysql_select_db('projectfrst');$newid=$_SESSION["regrsid"];
 
$sql="select * from frontregistration INNER JOIN additionalreg INNER JOIN interest ON frontregistration.id=additionalreg.id and frontregistration.id=interest.sender_id where interest.receiver_id=$newid and interest.status=1 ";
$res=mysql_query($sql);		
while($row=mysql_fetch_array($res))
{
	
	
	
		echo "<tr><td>".$row['fname']."</td>";
        echo "<td>".$row['mobile']."</td>";
		echo "<td>".$row['dob']."</td>";
		echo "<td>".$row['educat']."</td>";
		echo "<td>".$row['occcat']."</td>";
		$sendid=$row['sender_id']; 
		echo "<input type='hidden' name='sendid' value='$sendid'>";
	     
		echo "<td> <a href='viewotherprofile.php?id=$sendid'>Click Here</a></td>";
		echo "<td> <a href='accept.php?id=$sendid' style='text-decoration:none'><button type='button'>ACCEPT</a> <br>";
		echo " <a href='deny.php?id=$sendid' style='text-decoration:none'><button type='button'>DENY</a></td>";
		
		
	 
}

?>

</tr>
</table>
</form>
</div>
</div>
</div>	
</body>
</html>