<!doctype html>
<html>
<head>
<meta charset="utf-8">

<title>Untitled Document</title>
<link href="css/gallery.css" rel="stylesheet" type="text/css">
</head>

<body>
<div class="wrapper">
<div class="header">
<div class="logo">
<img src="images/logo.png"/>
</div>
<div id="hmenu"> 
<ul>
		<li><a href="#">MY HOME PAGE</a></li>
    	<li><a href="interestrecieved.php">INTEREST RECEIVED</a></li>
    	<!--<li><a href="int_snd.php">INTEREST SEND</a></li>-->
    	<li><a href="payment.php">PAYMENT PLANS</a></li>
    	<li><a href="userprofile.php">VIEW MY PROFILE</a></li>
        <li><a href="logout.php">LOGOUT</a></li>
	</ul>
</div> 

</div>

<div class="centermake">
<div class="d2" style="background-image:url(images/download%20(1).jpg)">
</div>

<div class="d3" style="background-image:url(images/happy-wedding_2527651c.jpg)">
</div>

<div class="d4" style="background-image:url(images/images.jpg)">
</div>

</div>
</div>
</body>
</html>