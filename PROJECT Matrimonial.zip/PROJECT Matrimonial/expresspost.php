<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
<?php 
$servername="localhost";
$username="root";
$password="";

$conn=mysql_connect("$servername","$username","$password");
mysql_select_db('projectfrst');
session_start();
$ids=$_GET['id'];//recieverid


 $newid=$_SESSION["regrsid"];
 $sql="select * from frontregistration where id=$newid";
 $res=mysql_query($sql);
 $fet=mysql_fetch_object($res);
$id=$fet->id;//senderid;(current user id)

        if(isset($_POST['express']))
	      {
			  echo "ghff";
				 $sql3="insert into interest(sender_id,receiver_id,status)values($id,$ids,1)";
		 		 $res3=mysql_query($sql3);
				 
	        header("location:viewotherprofile.php?id=$ids");    
	      }
	   
   
 

?>

</body>
</html>