<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
<?php
$servername="localhost";
$username="root";
$password="";
$conn=mysql_connect("$servername","$username","$password");
mysql_select_db('projectfrst');
session_start();
$newid=$_SESSION["regrsid"];//reciever id//current user

 $sendid=$_GET['id'];//senderid
		
		$sql2="UPDATE interest SET status=2 where receiver_id=$newid and sender_id=$sendid";
		$res2=mysql_query($sql2);
		
		header("location:interestrecieved.php");
	
?>
</body>
</html>