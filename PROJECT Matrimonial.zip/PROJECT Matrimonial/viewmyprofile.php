<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Logo</title>

<link href="css/viewmyprocss.css" rel="stylesheet" type="text/css">

<body>
<?php

$servername="localhost";
$username="root";
$password="";

$conn=mysql_connect("$servername","$username","$password");
mysql_select_db('projectfrst');
session_start();
 $newid=$_SESSION["regrsid"];
 $sql="select * from frontregistration where id=$newid";
 $res=mysql_query($sql);
 $fet=mysql_fetch_object($res);
$id=$fet->id;

$sql="SELECT * FROM frontregistration INNER JOIN additionalreg ON frontregistration.id=additionalreg.id WHERE frontregistration.id=$id ";

$result=mysql_query($sql);

$fet=mysql_fetch_object($result);

if(isset($_POST["update"]))
{
		$fname=$_POST["fname"];
		$age=$_POST["age"];
		$gender=$_POST["gender"];
		$dob=$_POST["dob"];
		$community=$_POST["community"];
		$denom=$_POST["denom"];
		$centi=$_POST["centi"];
		$feet=$_POST["feet"];
		$native=$_POST["native"];
		$mobile=$_POST["mobile"];
		$email=$_POST["email"];
		$mstatus=$_POST["mstatus"];
	  $withme=$_POST["withme"];
	 $withoutme=$_POST["withoutme"];
	 $fstatus=$_POST["fstatus"];
	 $nativecountry=$_POST["nativecountry"];
	 $nativeplace=$_POST["nativeplace"];
	 $residecountry=$_POST["residecountry"];
	 $diocese=$_POST["diocese"];
	 $parishname=$_POST["parishname"];
	 $bldgrp=$_POST["bldgrp"];
	 $complexion=$_POST["complexion"];
	 $weight=$_POST["weight"];
	 $body=$_POST["body"];
	 $pstatus=$_POST["pstatus"];
	 $educat=$_POST["educat"];
	 $occdetail=$_POST["occdetail"];
	 $occcat=$_POST["occcat"];
	 $workfirm=$_POST["workfirm"];
	 $workcountry=$_POST["workcountry"];
	 $emplcat=$_POST["emplcat"];
	 $anninc=$_POST["anninc"];
	 $fathname=$_POST["fathname"];
	 $fathhouse=$_POST["fathhouse"];
	 $fathplac=$_POST["fathplac"];
	 $fathocc=$_POST["fathocc"];
	 $mothname=$_POST["mothname"];
	 $mothhouse=$_POST["mothhouse"];
	 $mothplac=$_POST["mothplac"];
	 $mothocc=$_POST["mothocc"];
	 $brom=$_POST["brom"];
	 $brou=$_POST["brou"];
	 $nopriest=$_POST["nopriest"];
	 $sism=$_POST["sism"];
	 $sisu=$_POST["sisu"];
	 $nonun=$_POST["nonun"];
	 $commadress=$_POST["commadress"];
	 $pincode=$_POST["pincode"];
	 $abtcan=$_POST["abtcan"];
	 $desig=$_POST["desig"];
	$subname=$_POST["subname"];
	 $subnum=$_POST["subnum"];
	$sql5=" update frontregistration set fname='$fname',age='$age',gender='$gender',dob='$dob',community='$community',denom='$denom',centi='$centi',feet='$feet',native='$native',mobile='$mobile',email='$email' where id=$id";
	
	$res5=mysql_query($sql5);
	$sql6="update additionalreg set mstatus='$mstatus',withme='$withme',withoutme='$withoutme',fstatus='$fstatus',nativecountry='$nativecountry',nativeplace='$nativeplace',residecountry='$residecountry',diocese='$diocese',parishname='$parishname',bldgrp='$bldgrp',complexion='$complexion',bldgrp='$bldgrp',complexion='$complexion',weight='$weight',body='$body',pstatus='$pstatus',educat='$educat',occdetail='$occdetail',occcat='$occcat',workfirm='$workfirm',workcountry='$workcountry',emplcat='$emplcat',anninc='$anninc',fathname='$fathname',fathhouse='$fathhouse',fathplac='$fathplac',fathocc='$fathocc',mothname='$mothname',mothhouse='$mothhouse',mothplac='$mothplac',mothocc='$mothocc',brom='$brom',brou='$brou',nopriest='$nopriest',sism='$sism',sisu='$sisu',nonun='$nonun',commadress='$commadress',pincode='$pincode',abtcan='$abtcan',desig='$desig',subname='$subname',subnum='$subnum' where id=$id";
	$res6=mysql_query($sql6);
	header("Location:userprofile.php");
	}
	
?>
<div class="wraper">
<div class="header">
<div class="logo">
<img src="images/logo.png"/>
</div>
<div id="hmenu"> 
<ul>
		<li><a href="#">MY HOME PAGE</a></li>
    	<li><a href="interestrecieved.php">INTEREST RECEIVED</a></li>
    	<!--<li><a href="int_snd.php">INTEREST SEND</a></li>-->
    	<li><a href="payment.php">PAYMENT PLANS</a></li>
    	<li><a href="userprofile.php">VIEW MY PROFILE</a></li>
        <li><a href="logout.php">LOGOUT</a></li>
	</ul>
</div> 
</div>
<div class="container">
<div class="table1">
<form method="post" action="#" enctype="multipart/form-data">

<table border="1">
<tr>
		<th>Name</th> <td><input type="text" name="fname" value="<?php echo $fet->fname;?>"><br></td></tr>
		<th>Age</th> <td><input type="text" name="age" value="<?php echo $fet->age;?>"><br></td></tr>
		<tr><th>Gender</th> <td> <input type="radio" name="gender" value="male" <?php if($fet->gender=="male") echo 'checked';?>>Male
        	  <input type="radio" name="gender" value="female"<?php if($fet->gender=="female") echo 'checked';?> >Female<br></td></tr>
       <tr><th> Date of Birth</th> <td> <input type="date" name="dob" value="<?php echo $fet->dob;?>"><br></td></tr>
        <tr><th>Community</th> <td> <input type="radio" name="community" id="catholic" value="catholic"<?php if($fet->community=="catholic") echo 'checked';?> onChange="checkdenom1();" >Catholic
        	  <input type="radio" name="community" id="noncatholic" value="noncatholic"<?php if($fet->community=="noncatholic") echo 'checked';?> onChange="checkdenom2();" >Non Catholic<br></td></tr>
         <tr><th>Denomination </th> <td><select name="denom">
        			<option hidden="">--Select--</option>
        			<option value="angloindian"<?php if($fet->denom=='angloindian') echo "selected";?> id="d1">ANGLO INDIAN</option>
                    <option value="knanayacatholic"<?php if($fet->denom=='knanayacatholic') echo "selected";?> id="d2">KNANAYA CATHOLIC</option>
                    <option value="rclatin" id="d3"<?php if($fet->denom=='rclatin') echo "selected";?>>RC LATIN</option>
                    <option value="syro" id="d4"<?php if($fet->denom=='syro') echo "selected";?>>SYRO MALABAR</option>
                    <option value="orthodox"<?php if($fet->denom=='orthodox') echo "selected";?> id="d5">ORTHODOX</option>
                    <option value="jacobite"<?php if($fet->denom=='jacobite') echo "selected";?> id="d6">JACOBITE</option>
                    <option value="marthoma"<?php if($fet->denom=='marthoma') echo "selected";?> id="d7">MARTHOMA</option>
                    <option value="csi"<?php if($fet->denom=='csi') echo "selected";?> id="d8">CSI</option>
            		</option></select><br></td></tr>
       <tr><th>Height </th> <td><select name="centi" id="he" onChange="convertcm();">
        			<option hidden="">Centimeters</option>
                    <?php for($i=130;$i<=250;$i++) {?>
        			<option value="<?php echo $i ?>"<?php if($fet->centi==$i) echo "selected";?>><?php echo $i ?></option>
                    <?php }?>
                    </select>
                    <select name="feet"  onChange="convertfeet;" >
                    <option hidden="">Feet</option>
                     <?php for($i=0.5;$i<=5;$i++) {?>
        			<option value="<?php echo $i ?>"<?php if($fet->feet==$i) echo "selected";?>><?php echo $i ?></option>
                    <?php }?>
        			<option value=""></option></select><br></td></tr>
        <tr><th>Native place </th> <td><?php

								$sql="select * from country";
								$res=mysql_query($sql);
										?>
						<select name="native">
						<option value="">Select your country</option>
									<?php
									while($fetch=mysql_fetch_object($res))
									{
										$nat=$fetch->id;
									?>
                                     <option value="<?php echo $nat;?>"<?php if($fet->feet==$nat) echo "selected";?>><?php echo $fetch->country_name;?></option>
 									<?php   
									}
									?></select><br></td></tr>
        <tr><th>Mobile No.</th> <td> <input type="text" name="mobile" value="<?php echo $fet->mobile?>" ><br></td></tr>
        <tr><th>Email id </th> <td><input type="text" name="email" value="<?php echo $fet->email?>" ><br></td></tr>
        <tr><th>Marital status</th><td><select name="mstatus">
        			<option value="single"<?php if($fet->mstatus=='single') echo "selected";?>>Single</option>
                    <option value="widower"<?php if($fet->mstatus=='widower') echo "selected";?>>Widow/Widower</option></td></tr>
      <tr><th>Number of children</th> <td>with me<select name="withme">
        			<?php for($i=0;$i<=10;$i++) {?>
        			<option value="<?php echo $i ?>"<?php if($fet->withme==$i) echo "selected";?>><?php echo $i ?></option>
                    <?php }?></select>
                    with out<select name="withoutme">
        			<?php for($i=0;$i<=10;$i++) {?>
        			<option value="<?php echo $i ?>"<?php if($fet->withoutme==$i) echo "selected";?>><?php echo $i ?></option>
                    <?php }?>
                    </select><br></td></tr>
        <tr><th>Family Status</th> <td><select name="fstatus">
        			<option value="lower"<?php if($fet->fstatus=='lower') echo "selected";?>>Lower Class</option>
                    <option value="middle"<?php if($fet->fstatus=='middle') echo "selected";?>>Middle Class</option>
                    <option value="upper"<?php if($fet->fstatus=='upper') echo "selected";?>>Upper Class</option></select>
          			 </td></tr>               
         <tr><th>Native country </th> <td><?php

								$sql="select * from country";
								$res=mysql_query($sql);
										?>
						<select name="nativecountry">
						<option value="">Select your country</option>
									<?php
									while($fetch=mysql_fetch_object($res))
									{	$nc=$fetch->id;
									?>
                                     <option value="<?php echo $nc;?>"<?php if($fet->nativecountry==$nc) echo "selected";?>><?php echo $fetch->country_name;?></option>
 									<?php   
									}
									?></select><br></td></tr>
                                    
          <tr><th>Native Place</th><td><input type="text" name="nativeplace" value="<?php echo $fet->nativeplace;?>" ></td></tr>
          <tr><th>Residing country </th> <td><?php

								$sql="select * from country";
								$res=mysql_query($sql);
										?>
						<select name="residecountry">
						<option value="">Select your country</option>
									<?php
									while($fetch=mysql_fetch_object($res))
									{$rc=$fetch->id;
									?>
                                     <option value="<?php echo $rc;?>"<?php if($fet->residecountry==$rc) echo "selected";?>><?php echo $fetch->country_name;?></option>
 									<?php   
									}
									?></select><br></td></tr>
         <tr><th>Diocese</th> <td><select name="diocese">
        			<option value="north">North</option>
                    <option value="east">East</option>
                    <option value="west">West</option>
                    <option value="south">South</option></select>
          			 </td></tr>                                        
          <tr><th>Parish Name</th><td><input type="text" name="parishname" value="<?php echo $fet->parishname;?>" ></td></tr>                          
         <tr><th>Blood Group</th> <td><select name="bldgrp">
        			<option value="0+"<?php if($fet->bldgrp=='0+') echo "selected";?>>O+</option>
                    <option value="0-"<?php if($fet->bldgrp=='0-') echo "selected";?>>O-</option>
                    <option value="A+"<?php if($fet->bldgrp=='A+') echo "selected";?>>A+</option>
                    <option value="A-"<?php if($fet->bldgrp=='A-') echo "selected";?>>A-</option>
                    <option value="B+"<?php if($fet->bldgrp=='B+') echo "selected";?>>B+</option>

                    <option value="B-"<?php if($fet->bldgrp=='B-') echo "selected";?>>B-</option>
                    <option value="AB+"<?php if($fet->bldgrp=='AB+') echo "selected";?>>AB+</option>
                    <option value="AB-"<?php if($fet->bldgrp=='AB-') echo "selected";?>>AB-</option>
                    </select>
          			 </td></tr>                        
<tr><th>Complexion </th> <td><select name="complexion">
        			<option hidden="">Select complexion type</option>
        			<option value="fair"<?php if($fet->complexion=='fair') echo "selected";?> >FAIR</option>
                    <option value="wheatish"<?php if($fet->complexion=='wheatish') echo "selected";?> >WHEATISH</option>
                    <option value="mbrown"<?php if($fet->complexion=='mbrown') echo "selected";?> >MEDIUM BROWN</option>
                    <option value="brown"<?php if($fet->complexion=='brown') echo "selected";?> >BROWN</option>
                    <option value="dbrown"<?php if($fet->complexion=='dbrown') echo "selected";?> >DARK BROWN</option>
                    <option value="ibrown"<?php if($fet->complexion=='ibrown') echo "selected";?>>INTENSE DARK</option>
                    
            		</option></select><br></td></tr>
                    
                    
       <tr><th>Weight</th> <td><select name="weight" >
        			<option hidden="">weight</option>
                    <?php for($i=40;$i<=150;$i++) {?>
        			<option value="<?php echo $i ?>"><?php echo $i ?></option>
                    <?php }?>
                    </select>
                    <br></td></tr>
        <tr><th>Body Type</th><td>  <input type="radio" name="body" value="slim" <?php if($fet->body=="slim") echo 'checked';?> >Slim   
				     <input type="radio" name="body" value="athelitic" <?php if($fet->body=="athelitic") echo 'checked';?>>Athelitic<br>
                <input type="radio" name="body" value="average" <?php if($fet->body=="average") echo 'checked';?>>Average
                <input type="radio" name="body" value="heavy" <?php if($fet->body=="heavy") echo 'checked';?>>Heavy</td></tr>
                <tr><th>Physical Status</th> <td> <input type="radio" name="pstatus" value="normal"<?php if($fet->pstatus=="normal") echo 'checked';?>>Normal
        	  <input type="radio" name="pstatus" value="disabled" <?php if($fet->pstatus=="disabled") echo 'checked';?> >Disabled<br></td></tr>
              
       
                </table>
                    </div>
                    
                    
                    
                    <div class="table2">
                    <table border="1">
      <tr><th>Education Category </th> <td><select name="educat">
        			<option hidden="">--select--</option>
        			<option value="ad"<?php if($fet->educat=='ad') echo "selected";?>  >Associate Degrees</option>
                    <option value="bd" <?php if($fet->educat=='bd') echo "selected";?> >Bachelor's Degrees</option>
                    <option value="md" <?php if($fet->educat=='md') echo "selected";?>>Master's Degrees</option>
                    <option value="dd" <?php if($fet->educat=='dd') echo "selected";?>>Doctoral Degrees</option>
                    
         <tr><th>Occupation Details</th> <td><input type="text" name="occdetail" value="<?php echo $fet->occdetail;?>"><br></td></tr>
         
           <tr><th>Occupation Category </th> <td><select name="occcat">
        			<option hidden="">--select--</option>
        			<option value="pro" <?php if($fet->occcat=='pro') echo "selected";?>>Profession</option>
                    <option value="emp" <?php if($fet->occcat=='emp') echo "selected";?>>Employment</option>
                    <option value="mus" <?php if($fet->occcat=='mus') echo "selected";?>>Business</option>
                    <option value="others"<?php if($fet->occcat=='others') echo "selected";?> >Others</option>
                    </select><br></td></tr> 	
      <th>Working firm,Place</th> <td><input type="text" name="workfirm" value="<?php echo $fet->workfirm;?>"><br></td></tr>
        <tr><th>Working Country </th> <td><?php

								$sql="select * from country";
								$res=mysql_query($sql);
										?>
						<select name="workcountry">
						<option value="">Select your country</option>
									<?php
									while($fetch=mysql_fetch_object($res))
									{
										$wc=$fetch->id;
									?>
                                     <option value="<?php echo $wc; ?>"<?php if($fet->residecountry==$wc) echo "selected";?>><?php echo $fetch->country_name;?></option>
 									<?php   
									}
									?></select><br></td></tr>
        <tr><th>Employed Category </th> <td><select name="emplcat">
        			<option hidden="">--select--</option>
        			<option value="emp"<?php if($fet->emplcat=='emp') echo "selected";?> >Employed</option>
                    <option value="selpemp" <?php if($fet->emplcat=='selpemp') echo "selected";?> >Self-Employed</option>
                    <option value="pemp"<?php if($fet->emplcat=='pemp') echo "selected";?>  >Part-time Employees</option>
                    <option value="femp"<?php if($fet->emplcat=='femp') echo "selected";?>  >Fixed-term Employee</option>
                    <option value="cemp"<?php if($fet->emplcat=='cemp') echo "selected";?>  >Casual Employee</option>
                    </select><br></td></tr>
              <tr><th>Annual Income </th> <td><select name="anninc">
        			<option hidden="">--select--</option>
        			<option value="inr1"<?php if($fet->anninc=='inr1') echo "selected";?> >below ₹25000</option>
                    <option value="inr2" <?php if($fet->anninc=='inr2') echo "selected";?>>₹25000-₹100000</option>
                    <option value="inr3" <?php if($fet->anninc=='inr3') echo "selected";?>>₹100000-₹300000</option>
                    <option value="inr4" <?php if($fet->anninc=='inr4') echo "selected";?>>₹300000-₹500000</option>
                    <option value="inr5" <?php if($fet->anninc=='inr5') echo "selected";?>>₹500000-₹800000</option>
                    <option value="inr6" <?php if($fet->anninc=='inr6') echo "selected";?>>above ₹800000</option>
                    </select><br></td></tr>
                    <tr>
		<th>Father's Name</th> <td><input type="text" name="fathname" value="<?php echo $fet->fathname;?>"><br></td></tr>
		<tr><th>Father's House</th> <td> <input type="text" name="fathhouse" value="<?php echo $fet->fathhouse;?>"><br></td></tr>
        <tr><th>Father's Native Place</th> <td> <input type="text" name="fathplac" value="<?php echo $fet->fathplac;?>"><br></td></tr>
        <tr><th>Father's Occupation</th> <td> <input type="text" name="fathocc" value="<?php echo $fet->fathocc;?>"><br></td></tr>
       <th>Mothers's Name</th> <td><input type="text" name="mothname" value="<?php echo $fet->mothname;?>" ><br></td></tr>
		<tr><th>Mothers's House</th> <td> <input type="text" name="mothhouse" value="<?php echo $fet->mothhouse;?>" ><br></td></tr>
        <tr><th>Mothers's Native Place</th> <td> <input type="text" name="mothplac" value="<?php echo $fet->mothplac;?>"><br></td></tr>
        <tr><th>Mothers's Occupation</th> <td> <input type="text" name="mothocc" value="<?php echo $fet->mothocc;?>" ><br></td></tr> 
        <tr>
		<th>No. of Brothers Married</th> <td><input type="text" name="brom" value="<?php echo $fet->brom;?>" ><br></td></tr>
		<tr><th>No. of Brothers Unmarried</th> <td> <input type="text" name="brou" value="<?php echo $fet->brou;?>"><br></td></tr>
        <tr><th>No. of Priests</th> <td> <input type="text" name="nopriest" value="<?php echo $fet->nopriest?>"><br></td></tr>
        <th>No. of Sisters Married</th> <td><input type="text" name="sism" value="<?php echo $fet->sism;?>" ><br></td></tr>
		<tr><th>No. of Sisters Unmarried</th> <td> <input type="text" name="sisu" value="<?php echo $fet->sisu;?>" ><br></td></tr>
        <tr><th>No. of Nun</th> <td> <input type="text" name="nonun" value="<?php echo $fet->nonun;?>"><br></td></tr>
        <tr><th>Communication Adress</th><td> <textarea name="commadress" ><?php echo $fet->commadress;?></textarea></td></tr>
                <tr><th>PIN/Zip Code</th> <td><input type="text" name="pincode" value="<?php echo $fet->pincode;?>" ><br></td></tr>
                <tr><th>About the Candidate</th><td> <textarea name="abtcan" ><?php echo $fet->abtcan;?></textarea></td></tr>

                    
</table><br>

</div>
</div>
<div class="footer">
<center><input type="submit" name="update" value="UPDATE"></center>
</form>
</div>

</div>



</body>
</html>
