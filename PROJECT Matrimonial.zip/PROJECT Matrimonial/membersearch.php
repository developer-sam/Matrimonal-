<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
<link href="css/searchcss.css" rel="stylesheet" type="text/css">
</head>

<body>
<div class="wraper">
<div class="header">
<div class="logo">
<img src="images/logo.png"/>
</div>

</div>
<div class="container">
<div class="shosearch">
<?php
$servername="localhost";
$username="root";
$password="";

$conn=mysql_connect("$servername","$username","$password");
mysql_select_db('projectfrst');

if(isset($_POST['memsearch']))
{ 
	 $afrom=$_POST['afrom'];
	 $ato=$_POST['ato'];
	 $hfrom=$_POST['hfrom'];
	 $hto=$_POST['hto'];
	 $comm=$_POST['comm'];
	 $wplace=$_POST['wplace'];
	 $gen=$_POST['gender'];
    
	$sql3="select * from frontregistration INNER JOIN additionalreg ON frontregistration.id = additionalreg.id where gender='$gen' and age between $afrom and $ato and centi between $hfrom and $hto and community='$comm' and  workcountry='$wplace'";
	
       $res3=mysql_query($sql3);
	 
       while($row=mysql_fetch_object($res3))
		{?>
	
   		<h3>You searched for....</h3>
       <?php 
	  

        echo "<img src='images/$row->pic' height='200px' width='200px'><br>";
		
        echo "Name:".$row->fname."<br>";
        echo "Date of birth:".$row->dob."<br>";
        echo "Denomination:".$row->denom."<br>";
		$rid=$row->id;  
		echo "<a href='viewotherprofile.php?id=$rid'>View profile</a>";	
			
		?>
        
        
        <?php
		}
}
?>
</div>
	</div>
    </div>	
</body>
</html>
