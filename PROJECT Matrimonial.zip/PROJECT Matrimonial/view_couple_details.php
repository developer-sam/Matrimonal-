<!doctype html>
<html>
<head>
<meta charset="utf-8">



<title>Untitled Document</title>
<link href="css/vieew_couplescss.css" rel="stylesheet" type="text/css">
</head>

<body>

<div class="wraper">
<div class="header">
<div class="logo">
<img src="images/logo.png"/>
</div>
 <div id="hmenu"> 
<ul>
		<li><a href="#">MY HOME PAGE</a></li>
    	<li><a href="interestrecieved.php">INTEREST RECEIVED</a></li>
    	<!--<li><a href="int_snd.php">INTEREST SEND</a></li>-->
    	<li><a href="payment.php">PAYMENT PLANS</a></li>
    	<li><a href="userprofile.php">VIEW MY PROFILE</a></li>
        <li><a href="logout.php">LOGOUT</a></li>
	</ul>
</div> 
</div>
<div class="view">
<table bordercolor="#F70408">
<?php
$con=mysql_connect("localhost","root","");
mysql_select_db("projectfrst");
 $id=$_GET['id']; 
$sql="select * from success where id=$id";
 $res=mysql_query($sql);
 while($row=mysql_fetch_array($res))
 {
	  
                                
				                	
									$gn=$row['gname'];
									$gid=$row['gid'];
		                            $bn=$row['bname'];
									$bid=$row['bid'];
									$wed=$row['wedding'];
		                            $comment=$row['comments'];
									$pict=$row['image'];
									$pic=explode(",",$pict);
									$c=count($pic);
									
						for($i=0;$i<$c-1;$i++)
									{
								       echo "<tr><td><img src='images/$pic[$i]' height='50px' width='50px'></td></tr>";
									}			
								
						echo "<tr><th>Groom's Name</th><td>".$gn."</td></tr>";
		                echo "<tr><th>Groom's ID</th><td>".$gid."</td></tr>";
						echo "<tr><th>Bride's Name</th><td>".$bn."</td></tr>";
		                echo "<tr><th>Bride's ID</th><td>".$bid."</td></tr>";
						echo "<tr><th>Wedding Date</th><td>".$wed."</td></tr>";
		                echo "<tr><th>Comments About  Lifepartner.in Matrimony</th><td>".$comment."</td></tr>";
                        echo "</table>";
 }
?>

</table>
</div>
</div>
</body>
</html>