<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Additional_registration</title>
<link href="css/update_regcss.css" rel="stylesheet" type="text/css">
</head>

<body>
<div class="wraper">
	<div class="header">
    <div class="logo">
<img src="images/logo.png"/>
</div>
    </div>
    <div class="container">
    <div class="formlayer1">
    <div class="form">
<table bordercolor="#F0090D">


<?php
$servername="localhost";
$username="root";
$password="";

$conn=mysql_connect("$servername","$username","$password");
mysql_select_db('projectfrst');
?>
<!--ENTER THE ADDITIONAL PERSONAL DETAILS-->
<form method="post" action="addreg_post.php" enctype="multipart/form-data">
<marquee>ENTER THE ADDITIONAL PERSONAL DETAILS</marquee>

		<tr><th><font face="Gill Sans" color="#F00538">Marital status</th><td><select name="mstatus">
        			<option value="single">Single</option>
                    <option value="widower">Widow/Widower</option></td></tr>
      <tr><th><font face="Gill Sans" color="#F00538">Number of children</th> <td>with me<select name="withme">
        			<?php for($i=0;$i<=10;$i++) {?>
        			<option value="<?php echo $i ?>"><?php echo $i ?></option>
                    <?php }?></select>
                    with out me<select name="withoutme">
        			<?php for($i=0;$i<=10;$i++) {?>
        			<option value="<?php echo $i ?>"><?php echo $i ?></option>
                    <?php }?>
                    </select><br></td></tr>
        <tr><th><font face="Gill Sans" color="#F00538">Family Status</th> <td><select name="fstatus">
        			<option value="lower">Lower Class</option>
                    <option value="middle">Middle Class</option>
                    <option value="upper">Upper Class</option></select>
          			 </td></tr>               
         <tr><th><font face="Gill Sans" color="#F00538">Native country </th> <td><?php

								$sql="select * from country";
								$res=mysql_query($sql);
										?>
						<select name="nativecountry">
						<option value="">Select your country</option>
									<?php
									while($fetch=mysql_fetch_object($res))
									{
									?>
                                     <option value="<?php echo $fetch->id;?>"><?php echo $fetch->country_name;?></option>
 									<?php   
									}
									?></select><br></td></tr>
                                    
          <tr><th><font face="Gill Sans" color="#F00538">Native Place</th><td><input type="text" name="nativeplace" ></td></tr>
          <tr><th><font face="Gill Sans" color="#F00538">Residing country </th> <td><?php

								$sql="select * from country";
								$res=mysql_query($sql);
										?>
						<select name="residecountry">
						<option value="">Select your country</option>
									<?php
									while($fetch=mysql_fetch_object($res))
									{
									?>
                                     <option value="<?php echo $fetch->id;?>"><?php echo $fetch->country_name;?></option>
 									<?php   
									}
									?></select><br></td></tr>
         <tr><th><font face="Gill Sans" color="#F00538">Diocese</th> <td><select name="diocese">
        			<option value="north">North</option>
                    <option value="east">East</option>
                    <option value="west">West</option>
                    <option value="south">South</option></select>
          			 </td></tr>                                        
          <tr><th><font face="Gill Sans" color="#F00538">Parish Name</th><td><input type="text" name="parishname" ></td></tr>                          
         <tr><th><font face="Gill Sans" color="#F00538">Blood Group</th> <td><select name="bldgrp">
        			<option value="0+">O+</option>
                    <option value="0-">O-</option>
                    <option value="A+">A+</option>
                    <option value="A-">A-</option>
                    <option value="B+">B+</option>
                    <option value="B-">B-</option>
                    <option value="AB+">AB+</option>
                    <option value="AB-">AB-</option>
                    </select>
          			 </td></tr>                        
                    </table>
        
</div>

<div class="form1">
<!--FILL YOUR PHYSICAL CHARACTERS-->
    <table bordercolor="#F0090D">
    <form method="post" action="" enctype="multipart/form-data">
<marquee>FILL YOUR PHYSICAL CHARACTERS</marquee>
<tr>

         <tr><th><font face="Gill Sans" color="#F00538">Complexion </th> <td><select name="complexion">
        			<option hidden="">Select complexion type</option>
        			<option value="fair" >FAIR</option>
                    <option value="wheatish" >WHEATISH</option>
                    <option value="mbrown" >MEDIUM BROWN</option>
                    <option value="brown" >BROWN</option>
                    <option value="dbrown" >DARK BROWN</option>
                    <option value="ibrown">INTENSE DARK</option>
                    
            		</option></select><br></td></tr>
       <tr><th><font face="Gill Sans" color="#F00538">Weight</th> <td><select name="weight" >
        			<option hidden="">weight</option>
                    <?php for($i=40;$i<=150;$i++) {?>
        			<option value="<?php echo $i ?>"><?php echo $i ?></option>
                    <?php }?>
                    </select>
                    <br></td></tr>
        <tr><th><font face="Gill Sans" color="#F00538">Body Type</th><td>  <input type="radio" name="body" value="slim" >Slim   
				     <input type="radio" name="body" value="athelitic">Athelitic<br>
                <input type="radio" name="body" value="average">Average
                <input type="radio" name="body" value="heavy">Heavy</td></tr>
       	<tr><th><font face="Gill Sans" color="#F00538">Physical Status</th> <td> <input type="radio" name="pstatus" value="normal"  checked>Normal
        	  <input type="radio" name="pstatus" value="disabled" >Disabled<br></td></tr>
        </table>
       
</div>
<div class="form2">
<!--ENTER YOUR EDUCATIONAL QUALIFICATION-->
    <table bordercolor="#F0090D" >
    <form method="post" action="" enctype="multipart/form-data">
<marquee>ENTER YOUR EDUCATIONAL QUALIFICATION</marquee>

		
         <tr><th><font face="Gill Sans" color="#F00538">Education Category </th> <td><select name="educat">
        			<option hidden="">--select--</option>
        			<option value="ad" >Associate Degrees</option>
                    <option value="bd" >Bachelor's Degrees</option>
                    <option value="md" >Master's Degrees</option>
                    <option value="dd" >Doctoral Degrees</option>
         <tr><th><font face="Gill Sans" color="#F00538">Occupation Details</th> <td><input type="text" name="occdetail" value=""><br></td></tr>
           <tr><th><font face="Gill Sans" color="#F00538">Occupation Category </th> <td><select name="occcat">
        			<option hidden="">--select--</option>
        			<option value="pro" >Profession</option>
                    <option value="emp" >Employment</option>
                    <option value="mus" >Business</option>
                    <option value="others" >Others</option>
                    </select><br></td></tr>
      <th><font face="Gill Sans" color="#F00538">Working firm,Place</th> <td><input type="text" name="workfirm" value=""><br></td></tr>
        <tr><th><font face="Gill Sans" color="#F00538">Working Country </th> <td><?php

								$sql="select * from country";
								$res=mysql_query($sql);
										?>
						<select name="workcountry">
						<option value="">Select your country</option>
									<?php
									while($fetch=mysql_fetch_object($res))
									{
									?>
                                     <option value="<?php echo $fetch->id;?>"><?php echo $fetch->country_name;?></option>
 									<?php   
									}
									?></select><br></td></tr>
        <tr><th><font face="Gill Sans" color="#F00538">Employed Category </th> <td><select name="emplcat">
        			<option hidden="">--select--</option>
        			<option value="emp" >Employed</option>
                    <option value="selpemp" >Self-Employed</option>
                    <option value="pemp" >Part-time Employees</option>
                    <option value="femp" >Fixed-term Employee</option>
                    <option value="cemp" >Casual Employee</option>
                    </select><br></td></tr>
              <tr><th><font face="Gill Sans" color="#F00538">Annual Income </th> <td><select name="anninc">
        			<option hidden="">--select--</option>
        			<option value="inr1" >below ₹25000</option>
                    <option value="inr2" >₹25000-₹100000</option>
                    <option value="inr3" >₹100000-₹300000</option>
                    <option value="inr4" >₹300000-₹500000</option>
                    <option value="inr5" >₹500000-₹800000</option>
                    <option value="inr6" >above ₹800000</option>
                    </select><br></td></tr>
        </table>
        </div>
        </div>
        <div class="formlayer2">
<div class="form3">
    <table bordercolor="#F0090D" >
    <form method="post" action="" enctype="multipart/form-data">
<marquee>ENTER YOUR PARENT DETAILS</marquee>
<tr>
		<th><font face="Gill Sans" color="#F00538">Father's Name</th> <td><input type="text" name="fathname" value=""><br></td></tr>
		<tr><th><font face="Gill Sans" color="#F00538">Father's House</th> <td> <input type="text" name="fathhouse" value=""><br></td></tr>
        <tr><th><font face="Gill Sans" color="#F00538">Father's Native Place</th> <td> <input type="text" name="fathplac" value=""><br></td></tr>
        <tr><th><font face="Gill Sans" color="#F00538">Father's Occupation</th> <td> <input type="text" name="fathocc" value=""><br></td></tr>
       <th><font face="Gill Sans" color="#F00538">Mothers's Name</th> <td><input type="text" name="mothname" value="" ><br></td></tr>
		<tr><th><font face="Gill Sans" color="#F00538">Mothers's House</th> <td> <input type="text" name="mothhouse" value="" ><br></td></tr>
        <tr><th><font face="Gill Sans" color="#F00538">Mothers's Native Place</th> <td> <input type="text" name="mothplac" value=""><br></td></tr>
        <tr><th><font face="Gill Sans" color="#F00538">Mothers's Occupation</th> <td> <input type="text" name="mothocc" value="" ><br></td></tr> 
        </table>
</div>
<div class="form4">
<!--ENTER YOUR SIBLINGS DETAILS-->
    <table bordercolor="#F0090D" >
    <form method="post" action="" enctype="multipart/form-data">
<marquee>ENTER YOUR SIBLINGS DETAILS</marquee>
<tr>
		<th><font face="Gill Sans" color="#F00538">No. of Brothers Married</th> <td><input type="text" name="brom" value="" ><br></td></tr>
		<tr><th><font face="Gill Sans" color="#F00538">No. of Brothers Unmarried</th> <td> <input type="text" name="brou" value=""><br></td></tr>
        <tr><th><font face="Gill Sans" color="#F00538">No. of Priests</th> <td> <input type="text" name="nopriest" value=""><br></td></tr>
        <th><font face="Gill Sans" color="#F00538">No. of Sisters Married</th> <td><input type="text" name="sism" value="" ><br></td></tr>
		<tr><th><font face="Gill Sans" color="#F00538">No. of Sisters Unmarried</th> <td> <input type="text" name="sisu" value="" ><br></td></tr>
        <tr><th><font face="Gill Sans" color="#F00538">No. of Nun</th> <td> <input type="text" name="nonun" value=""><br></td></tr>
        </table>
</div>
<div class="form5">
<!--ENTER YOUR SIBLINGS DETAILS-->
    <table bordercolor="#F0090D" >
    <form method="post" action="" enctype="multipart/form-data">
<marquee>ADD YOUR CONTACT DETAILS</marquee>
				<tr><th><font face="Gill Sans" color="#F00538">Communication Adress</th><td> <textarea name="commadress" ></textarea></td></tr>
                <tr><th><font face="Gill Sans" color="#F00538">PIN/Zip Code</th> <td><input type="text" name="pincode" value="" ><br></td></tr>
                <tr><th><font face="Gill Sans" color="#F00538">About the Candidate</th><td> <textarea name="abtcan" ></textarea></td></tr>
                <tr><th><font face="Gill Sans" color="#F00538">Profile created by</th><td><select name="desig">
        			<option hidden="">--select--</option>
        			<option value="mr" >MR.</option>
                    <option value="mrs" >MRS.</option>
                    <option value="ms" >MS.</option>
                    </select><br>
                    <input type="text" name="subname" value="" placeholder="Enter your Name" ><br>
                    <input type="text" name="subnum" value="" placeholder="Enter your Number" ><br></td></tr>
                    </td></tr>
                 <tr><th>Verify and Submit</th><td> <center><input type="submit" name="submit" value="SUBMIT" ></center></td></tr>
        </table>
</div>

</div>
</body>
</html>
