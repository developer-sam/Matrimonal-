<?php
$servername="localhost";
$username="root";
$password="";

$conn=mysql_connect($servername,$username,$password);
mysql_select_db("projectfrst");

session_start();
$curdate=date('Y-m-d');
if(isset($_POST["login"]))
{
	$user=$_POST["user"];
	$pass=$_POST["pass"];
	
	$sql= "select *  from log where user='$user' AND pass='$pass'";
	 $res=mysql_query($sql);
	 $rows=mysql_num_rows($res);
	
	 
	 if($rows>0)
	 {
		$row=mysql_fetch_object($res);
		  $usnme=$row->user;
		  $pswrd=$row->pass;
		  $regid=$row->regid;	
		  $sql2="select * from frontregistration where id=$regid";
		  $resl=mysql_query($sql2);
		 $row1=mysql_fetch_object($resl);
		  $exdate=$row1->exdate;
		 $_SESSION['regrsid']=$regid;
		
		if($curdate==$exdate)
		{
			header("location:payment.php");
		}
		else 
		{
		header("location:userprofile.php");
		}
	 }
	else
	{ 
	header("location:invalidlogin.php");
	}
	}

?>