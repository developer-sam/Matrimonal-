<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Logo</title>
<link href="css/regsuceescss.css" rel="stylesheet" type="text/css">



<body>
<?php
$servername="localhost";
$username="root";
$password="";

$conn=mysql_connect($servername,$username,$password);
mysql_select_db("projectfrst");


session_start();
$id=$_SESSION['ids'];
$_SESSION['id']=$id;
if(isset($_POST["submit"]))
{
	$pic=$_FILES['pic']['name'];
  	move_uploaded_file($_FILES['pic']['tmp_name'],"images/".$pic);
	
	 echo $sql="update frontregistration set pic='$pic'where id=$id";
	
	 mysql_query($sql);
	 
	 header("location:registration.php");
	
}

?>
<div class="wraper">
<div class="header">
<div class="logo">
<img src="images/logo.png"/>
</div>

</div>
<div class="container">
<h2>Registration Succesfull  !!!!!!</h2>
<h3>Welcome to <strong>Life Partner.in</strong></h3>
<h3>Ur Id is <?php echo $id=$_SESSION['ids'];?></strong></h3>
<form method="post" action="" enctype="multipart/form-data">
<h3>Please upload your image <input type="file" name="pic" value="" ></h3>
<h3><input type="submit" name="submit" value="Upload Picture" ></h3>
</form>
 </div>
</div>










</body>
</html>
