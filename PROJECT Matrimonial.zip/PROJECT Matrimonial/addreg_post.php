<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Logo</title>

</head>

<body>
<?php
$servername="localhost";
$username="root";
$password="";

$conn=mysql_connect("$servername","$username","$password");
mysql_select_db('projectfrst');


if(isset($_POST["submit"]))
{
	 $mstatus=$_POST["mstatus"];
	  $withme=$_POST["withme"];
	 $withoutme=$_POST["withoutme"];
	 $fstatus=$_POST["fstatus"];
	 $nativecountry=$_POST["nativecountry"];
	 $nativeplace=$_POST["nativeplace"];
	 $residecountry=$_POST["residecountry"];
	 $diocese=$_POST["diocese"];
	 $parishname=$_POST["parishname"];
	 $bldgrp=$_POST["bldgrp"];
	 $complexion=$_POST["complexion"];
	 $weight=$_POST["weight"];
	 $body=$_POST["body"];
	 $pstatus=$_POST["pstatus"];
	 $educat=$_POST["educat"];
	 $occdetail=$_POST["occdetail"];
	 $occcat=$_POST["occcat"];
	 $workfirm=$_POST["workfirm"];
	 $workcountry=$_POST["workcountry"];
	 $emplcat=$_POST["emplcat"];
	 $anninc=$_POST["anninc"];
	 $fathname=$_POST["fathname"];
	 $fathhouse=$_POST["fathhouse"];
	 $fathplac=$_POST["fathplac"];
	 $fathocc=$_POST["fathocc"];
	 $mothname=$_POST["mothname"];
	 $mothhouse=$_POST["mothhouse"];
	 $mothplac=$_POST["mothplac"];
	 $mothocc=$_POST["mothocc"];
	 $brom=$_POST["brom"];
	 $brou=$_POST["brou"];
	 $nopriest=$_POST["nopriest"];
	 $sism=$_POST["sism"];
	 $sisu=$_POST["sisu"];
	 $nonun=$_POST["nonun"];
	 $commadress=$_POST["commadress"];
	 $pincode=$_POST["pincode"];
	 $abtcan=$_POST["abtcan"];
	 $desig=$_POST["desig"];
	$subname=$_POST["subname"];
	 $subnum=$_POST["subnum"];
	 
$sql="insert into additionalreg (mstatus,withme,withoutme,fstatus,nativecountry,nativeplace,residecountry,diocese,parishname,bldgrp,complexion,weight,body,pstatus,educat,occdetail,occcat,workfirm,workcountry,emplcat,anninc,fathname,fathhouse,fathplac,fathocc,mothname,mothhouse,mothplac,mothocc,brom,brou,nopriest,sism,sisu,nonun,commadress,pincode,abtcan,desig,subname,subnum) values ('$mstatus','$withme','$withoutme','$fstatus','$nativecountry','$nativeplace','$residecountry','$diocese','$parishname','$bldgrp','$complexion','$weight','$body','$pstatus','$educat','$occdetail','$occcat','$workfirm','$workcountry','$emplcat','$anninc','$fathname','$fathhouse','$fathplac','$fathocc','$mothname','$mothhouse','$mothplac','$mothocc','$brom','$brou','$nopriest','$sism','$sisu','$nonun','$commadress','$pincode','$abtcan','$desig','$subname','$subnum')";
	$res=mysql_query($sql);
	header("location:regsucess.php");
}
?>
</body>
</html>
